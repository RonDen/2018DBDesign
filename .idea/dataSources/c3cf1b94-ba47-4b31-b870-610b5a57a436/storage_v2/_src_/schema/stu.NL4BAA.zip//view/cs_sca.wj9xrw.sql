create view cs_sca as
select `stu`.`s`.`sno` AS `sno`,`stu`.`s`.`sname` AS `sname`,`stu`.`sc`.`grade` AS `Grade`
from `stu`.`s`
       join `stu`.`sc`
       join `stu`.`c`
where ((`stu`.`sc`.`sno` = `stu`.`s`.`sno`) and (`stu`.`sc`.`cno` = `stu`.`c`.`cno`) and
       (`stu`.`c`.`cname` like '%数据库%'));

