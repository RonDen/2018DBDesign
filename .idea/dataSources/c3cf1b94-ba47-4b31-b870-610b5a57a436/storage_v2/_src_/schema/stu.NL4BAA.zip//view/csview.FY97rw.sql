create view csview as
select `stu`.`s`.`sno`   AS `sno`,
       `stu`.`s`.`sname` AS `sname`,
       `stu`.`s`.`sage`  AS `sage`,
       `stu`.`s`.`sex`   AS `sex`,
       `stu`.`s`.`sdept` AS `sdept`
from `stu`.`s`
where (`stu`.`s`.`sdept` = '计算机');

